import logo from './치아.png';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          반짝반짝 치카치카
        </p>
        <a
          className="App-link"
          href="https://search.naver.com/search.naver?where=nexearch&sm=tab_etc&mra=blZI&x_csa=%7B%22pkid%22%3A685%7D&pkid=685&x_nqx=%7B%22theme%22%3A%22disease%22%2C%22pkid%22%3A%22685%22%2C%22os%22%3A%22%22%7D&qvt=0&query=%EC%B9%98%EC%95%84%20%EC%A7%88%ED%99%98"
          target="_blank"
          rel="noopener noreferrer"
        >
          치아질병 종류
        </a>
        <a
          className="App-link"
          href="https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyMjAzMTRfMjU2%2FMDAxNjQ3MjIzMjY5Mzc1.DvXGXLJ4wcFekBoRyNkVS4mKx4dViEnwiF8VecZJ1bYg.XciIcUm2xJChqy2JuuPukSac5JbP3JnFA6aUUtRJ3nog.JPEG.rosie_mary%2FIMG_6077.JPG&type=sc960_832"
          target="_blank"
          rel="noopener noreferrer"
        >
          세균맨
        </a>
        <a
          className="App-link"
          href="https://ko.wikihow.com/%EC%96%91%EC%B9%98%ED%95%98%EB%8A%94-%EB%B0%A9%EB%B2%95"
          target="_blank"
          rel="noopener noreferrer"
        >
          올바른 양치법
        </a>
        <text>
          치아 관리법을 소개하여 치아질병을 예방하도록 도와준다.
        </text>
      </header>
    </div>
  );
}

export default App;
